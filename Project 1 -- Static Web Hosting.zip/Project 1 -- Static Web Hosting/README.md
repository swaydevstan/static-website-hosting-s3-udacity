# Static Website Hosting on AWS S3 and distributed via CloudFront

This repository contains screenshot on static website hosting deployed on AWS S3 and served via cloudfront, for udacity project.

CloudFront URL: dbbcyhd8ghkx4.cloudfront.net